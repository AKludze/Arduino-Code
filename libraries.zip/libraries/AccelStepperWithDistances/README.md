# Accel Stepper with Distances

This library allow you to work with the popular AccelStepper library not with steps, but distances!

# Installation

To install this library, just place this entire folder as a subfolder in your
Arduino/lib/targets/libraries folder or install it via the arduino library manager!

# Credits

- [Mateus Junges][me]
- [Ariangelo H. Dias][ariangelo]

[me]: https://twitter.com/mateusjungess
[ariangelo]: https://github.com/ariangelo
