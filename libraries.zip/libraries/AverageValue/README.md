# AverageValue arduino library

